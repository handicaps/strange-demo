from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import time

#设置浏览器驱动，我用的是edge，如果要用chrome或者firefox直接改就行。
driver = webdriver.Edge()

#写这种或者login页面都可以
url = 'https://aiarena.tencent.com/p/user/login?redirect=https%3A%2F%2Faiarena.tencent.com%2Fp%2Fedu-exp%2F146%2Fdev%2Fmodel-accessment'

# 打开网页
driver.get(url)
wait = WebDriverWait(driver, 10)

#输入邮箱
target_element=driver.find_element(By.ID, "basic_email")
target_element.clear()
username = '2665038949@qq.com'
target_element.send_keys(username)

# 输入密码
password_element=driver.find_element(By.ID, "basic_password")
password_element.clear()
password = '@Wuxinyi0211'
password_element.send_keys(password)

#登录按钮
login_button = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, 'span.kaiwu-button button')))
login_button.click()
wait = WebDriverWait(driver, 10)
wait.until(EC.title_contains('模型评估'))
new_button = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, 'span.kaiwu-button button')))
new_button.click()

#找到表单
form_element = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CLASS_NAME, 'kaiwu-layer-form')))

#输入任务名称
task_name_input = form_element.find_element(By.ID, 'name')
task_name_input.send_keys("Task Name")

# 找到阵营A(点击，下拉，搜索，点击）
trigger = form_element.find_elements(By.CSS_SELECTOR, 'div.wrap___3JQo0') #div.ant-select')
trigger_a=trigger[0]
camp_a_trigger=trigger_a.find_element(By.CSS_SELECTOR, 'div.ant-select')
camp_a_trigger.click()
search_box = WebDriverWait(form_element, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, 'input.ant-input.ant-input-borderless')))
search_box.send_keys('6hh')  # 替换为你要测的模型A
option_locator = (By.XPATH, '//div[contains(@class, "ant-select-dropdown")]//div[contains(@class, "ant-select-item-option-content") and text()="6hh"]') # 替换为你要测的模型A
option = WebDriverWait(driver, 10).until(
    EC.visibility_of_element_located(option_locator) and EC.element_to_be_clickable(option_locator)
)
option.click()

# 找到阵营B(点击，下拉，搜索，点击）
trigger_b=trigger[1]
camp_b_trigger=trigger_b.find_element(By.CSS_SELECTOR, 'div.ant-select')
camp_b_trigger.click()

search_box = WebDriverWait(trigger_b, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, 'input.ant-input.ant-input-borderless')))
search_box.send_keys('baseline-level-3')  # 替换为你要测的模型B
option_locator = (By.XPATH, '//div[contains(@class, "ant-select-dropdown")]//div[contains(@class, "ant-select-item-option-content") and text()="baseline-level-3"]') # 替换为你要测的模型B
option = WebDriverWait(driver, 10).until(
    EC.visibility_of_element_located(option_locator) and EC.element_to_be_clickable(option_locator)
)
option.click()

#输入轮数，默认为5
num_element=form_element.find_element(By.CLASS_NAME, "ant-input-number-input")
num_element.clear()
num = 5
num_element.send_keys(num)

#点击确认
button_element = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//span[text()="确 定"]')))
button_element.click()

#静置，后关闭浏览器
time.sleep(3000)
driver.quit()


